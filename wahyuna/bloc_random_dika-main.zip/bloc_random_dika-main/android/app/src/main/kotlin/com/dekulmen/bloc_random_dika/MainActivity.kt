package com.dekulmen.bloc_random_dika

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
