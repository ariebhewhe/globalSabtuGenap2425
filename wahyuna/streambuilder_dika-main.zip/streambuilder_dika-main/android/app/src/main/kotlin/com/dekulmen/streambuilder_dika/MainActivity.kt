package com.dekulmen.streambuilder_dika

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
