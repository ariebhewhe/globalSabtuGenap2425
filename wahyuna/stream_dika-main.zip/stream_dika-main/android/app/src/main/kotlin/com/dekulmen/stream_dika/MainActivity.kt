package com.dekulmen.stream_dika

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
